SELECT nation.n_name, orders.o_orderkey, count(orders.o_orderkey)
FROM orders
INNER JOIN customer on orders.o_custkey = customer.c_custkey
INNER JOIN nation on nation.n_nationkey = customer.c_nationkey
INNER JOIN region on nation.n_regionkey = region.r_regionkey
GROUP BY nation.n_nationkey